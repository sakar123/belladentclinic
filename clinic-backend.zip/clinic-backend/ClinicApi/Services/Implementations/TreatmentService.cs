using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;
using ClinicApi.Models.Enumerations;

namespace ClinicApi.Services.Implementations
{
    public class TreatmentService : ITreatmentService
    {
        private readonly IRepository<Treatment> _treatmentRepository;
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<Staff> _staffRepository;
        private readonly IRepository<Service> _serviceRepository;
        private readonly IMapper _mapper;

        public TreatmentService(
            IRepository<Treatment> treatmentRepository,
            IRepository<Appointment> appointmentRepository,
            IRepository<Patient> patientRepository,
            IRepository<Staff> staffRepository,
            IRepository<Service> serviceRepository,
            IMapper mapper)
        {
            _treatmentRepository = treatmentRepository;
            _appointmentRepository = appointmentRepository;
            _patientRepository = patientRepository;
            _staffRepository = staffRepository;
            _serviceRepository = serviceRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<TreatmentDTO>> GetAllTreatmentsAsync()
        {
            var treatments = await _treatmentRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<TreatmentDTO>>(treatments);
        }

        public async Task<TreatmentDTO> GetTreatmentByIdAsync(Guid id)
        {
            var treatment = await _treatmentRepository.GetByIdAsync(id);
            return _mapper.Map<TreatmentDTO>(treatment);
        }

        public async Task<TreatmentDTO> CreateTreatmentAsync(TreatmentDTO treatmentDto)
        {
            if (!await _appointmentRepository.ExistsAsync(treatmentDto.appointment_id))
                throw new KeyNotFoundException("Appointment not found");
                
            if (!await _patientRepository.ExistsAsync(treatmentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _staffRepository.ExistsAsync(treatmentDto.staff_id))
                throw new KeyNotFoundException("Staff not found");
                
            if (!await _serviceRepository.ExistsAsync(treatmentDto.service_id))
                throw new KeyNotFoundException("Service not found");

            var treatment = _mapper.Map<Treatment>(treatmentDto);
            await _treatmentRepository.AddAsync(treatment);
            await _treatmentRepository.SaveChangesAsync();
            
            return _mapper.Map<TreatmentDTO>(treatment);
        }

        public async Task<TreatmentDTO> UpdateTreatmentAsync(Guid id, TreatmentDTO treatmentDto)
        {
            var existingTreatment = await _treatmentRepository.GetByIdAsync(id);
            if (existingTreatment == null)
                throw new KeyNotFoundException("Treatment not found");

            if (!await _appointmentRepository.ExistsAsync(treatmentDto.appointment_id))
                throw new KeyNotFoundException("Appointment not found");
                
            if (!await _patientRepository.ExistsAsync(treatmentDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _staffRepository.ExistsAsync(treatmentDto.staff_id))
                throw new KeyNotFoundException("Staff not found");
                
            if (!await _serviceRepository.ExistsAsync(treatmentDto.service_id))
                throw new KeyNotFoundException("Service not found");

            _mapper.Map(treatmentDto, existingTreatment);
            existingTreatment.updated_at= DateTime.UtcNow;
            
            _treatmentRepository.Update(existingTreatment);
            await _treatmentRepository.SaveChangesAsync();
            
            return _mapper.Map<TreatmentDTO>(existingTreatment);
        }

        public async Task<bool> DeleteTreatmentAsync(Guid id)
        {
            var treatment = await _treatmentRepository.GetByIdAsync(id);
            if (treatment == null)
                return false;

            _treatmentRepository.Delete(treatment);
            await _treatmentRepository.SaveChangesAsync();
            return true;
        }
    }
}
