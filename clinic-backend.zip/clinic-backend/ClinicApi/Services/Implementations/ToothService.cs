using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.DTOs;
using ClinicApi.Models.Entities;



namespace ClinicApi.Services.Implementations
{
    public class ToothService : IToothService
    {
        private readonly IRepository<Tooth> _toothRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<ToothStatus> _toothStatusRepository;
        private readonly IMapper _mapper;

        public ToothService(
            IRepository<Tooth> toothRepository,
            IRepository<Patient> patientRepository,
            IRepository<ToothStatus> toothStatusRepository,
            IMapper mapper)
        {
            _toothRepository = toothRepository;
            _patientRepository = patientRepository;
            _toothStatusRepository = toothStatusRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<ToothDTO>> GetAllTeethAsync()
        {
            var teeth = await _toothRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<ToothDTO>>(teeth);
        }

        public async Task<ToothDTO> GetToothByIdAsync(Guid id)
        {
            var tooth = await _toothRepository.GetByIdAsync(id);
            return _mapper.Map<ToothDTO>(tooth);
        }

        public async Task<ToothDTO> CreateToothAsync(ToothDTO toothDto)
        {
            if (!await _patientRepository.ExistsAsync(toothDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _toothStatusRepository.ExistsAsync(toothDto.tooth_status_id))
                throw new KeyNotFoundException("Tooth status not found");

            var tooth = _mapper.Map<Tooth>(toothDto);
            await _toothRepository.AddAsync(tooth);
            await _toothRepository.SaveChangesAsync();
            
            return _mapper.Map<ToothDTO>(tooth);
        }

        public async Task<ToothDTO> UpdateToothAsync(Guid id, ToothDTO toothDto)
        {
            var existingTooth = await _toothRepository.GetByIdAsync(id);
            if (existingTooth == null)
                throw new KeyNotFoundException("Tooth not found");

            if (!await _patientRepository.ExistsAsync(toothDto.patient_id))
                throw new KeyNotFoundException("Patient not found");
                
            if (!await _toothStatusRepository.ExistsAsync(toothDto.tooth_status_id))
                throw new KeyNotFoundException("Tooth status not found");

            _mapper.Map(toothDto, existingTooth);
            existingTooth.updated_at = DateTime.UtcNow;
            
            _toothRepository.Update(existingTooth);
            await _toothRepository.SaveChangesAsync();
            
            return _mapper.Map<ToothDTO>(existingTooth);
        }

        public async Task<bool> DeleteToothAsync(Guid id)
        {
            var tooth = await _toothRepository.GetByIdAsync(id);
            if (tooth == null)
                return false;

            _toothRepository.Delete(tooth);
            await _toothRepository.SaveChangesAsync();
            return true;
        }
    }
}
