using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using ClinicApi.Data.Repositories;
using ClinicApi.Models.Entities;
using ClinicApi.Models.DTOs;
namespace ClinicApi.Services.Implementations
{
    public class StaffService : IStaffService
    {
        private readonly IRepository<Staff> _staffRepository;
        private readonly IRepository<Person> _personRepository;
        private readonly IRepository<Role> _roleRepository;
        private readonly IRepository<Specialty> _specialtyRepository;
        private readonly IMapper _mapper;
        public StaffService(
            IRepository<Staff> staffRepository,
            IRepository<Person> personRepository,
            IRepository<Role> roleRepository,
            IRepository<Specialty> specialtyRepository,
            IMapper mapper)
        {
            _staffRepository = staffRepository;
            _personRepository = personRepository;
            _roleRepository = roleRepository;
            _specialtyRepository = specialtyRepository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<StaffDTO>> GetAllStaffAsync()
        {
            var staff = await _staffRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<StaffDTO>>(staff);
        }
        public async Task<StaffDTO> GetStaffByIdAsync(Guid id)
        {
            var staff = await _staffRepository.GetByIdAsync(id);
            return _mapper.Map<StaffDTO>(staff);
        }
        public async Task<StaffDTO> CreateStaffAsync(StaffDTO staffDto)
        {
            // Validate Role exists
            if (!await _roleRepository.ExistsAsync(staffDto.role_id))
                throw new KeyNotFoundException("Role not found");
            // Validate Specialty exists if provided
            if (staffDto.specialty_id.HasValue && !await _specialtyRepository.ExistsAsync(staffDto.specialty_id.Value))
                throw new KeyNotFoundException("Specialty not found");
            // Create Person first
            var person = _mapper.Map<Person>(staffDto);
            await _personRepository.AddAsync(person);
            await _personRepository.SaveChangesAsync();
            // Create Staff
            var staff = _mapper.Map<Staff>(staffDto);
            staff.person_id = person.id;
            await _staffRepository.AddAsync(staff);
            await _staffRepository.SaveChangesAsync();
            var createdStaff = await _staffRepository.GetByIdAsync(staff.id);
            return _mapper.Map<StaffDTO>(createdStaff);
        }
        public async Task<StaffDTO> UpdateStaffAsync(Guid id, StaffDTO staffDto)
        {
            var existingStaff = await _staffRepository.GetByIdAsync(id);
            if (existingStaff == null)
                throw new KeyNotFoundException("Staff not found");
            var existingPerson = await _personRepository.GetByIdAsync(existingStaff.person_id);
            if (existingPerson == null)
                throw new KeyNotFoundException("Person not found");
            // Validate Role exists
            if (!await _roleRepository.ExistsAsync(staffDto.role_id))
                throw new KeyNotFoundException("Role not found");
            // Validate Specialty exists if provided
            if (staffDto.specialty_id.HasValue && !await _specialtyRepository.ExistsAsync(staffDto.specialty_id.Value))
                throw new KeyNotFoundException("Specialty not found");
            // Update Person
            _mapper.Map(staffDto, existingPerson);
            _personRepository.Update(existingPerson);
            await _personRepository.SaveChangesAsync();
            // Update Staff
            _mapper.Map(staffDto, existingStaff);
            _staffRepository.Update(existingStaff);
            await _staffRepository.SaveChangesAsync();
            var updatedStaff = await _staffRepository.GetByIdAsync(id);
            return _mapper.Map<StaffDTO>(updatedStaff);
        }
        public async Task<bool> DeleteStaffAsync(Guid id)
        {
            var staff = await _staffRepository.GetByIdAsync(id);
            if (staff == null)
                return false;
            var person = await _personRepository.GetByIdAsync(staff.person_id);
            if (person != null)
            {
                _personRepository.Delete(person);
                await _personRepository.SaveChangesAsync();
            }
            _staffRepository.Delete(staff);
            await _staffRepository.SaveChangesAsync();
            return true;
        }
    }
}